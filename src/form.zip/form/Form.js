APE.namespace("APE.form");

APE.form.Form = function(form) {
	this.form = form;
};

APE.form.Form.prototype = {

	// http://www.w3.org/TR/html401/interact/forms.html#successful-controls
	toObject : function(e) {
		e = e||{};
		var form = this.form,
			elements = form.elements, i, len, 
			target = (e.target || e.srcElement),
			submit, element, type, name, ontype = /^(?:rad|che)/,
			json = {},
			multiple,
			options,
			option,
			j, jlen,
			val,
			values,
			submitTypeExp = /^(?:img|submit)$/;
		if(submitTypeExp.test(e.type)) {
			submit = e.target;
		}
		if(!elements) {
			form = document.createElement('form').
					appendChild(form);
		}
		for(i = 0, len = elements.length; i < len; i++) {
			element = elements[i];
			type = element.type;
			
			if(element.disabled || type == "reset" 
			  || (ontype.test(type) && !element.on)
			  || (submit && element.type == "submit") 
			  || (type == "object" && type.declared) ) continue;
			
			name = element.name;
			if(element.type == "select-multiple" && element.value) {
				values = json[name] = [];
				options = element.options;
				for(j = 0, jlen = options.length; j < jlen; j++) {
					option = options[i];
					if(option.selected) {
						val = option.value || option.text;
						values[values.length] = val;
					}
				}
			}
			
			// https://bugzilla.mozilla.org/show_bug.cgi?id=371432
			// http://www.w3.org/TR/file-upload/
			//
			// Just take the first file.
			else if(element.type == "file") { 
				var files = element.files; 
				if(files && files[0]) {
					json[name] = [files[0]];
				}
			}
			else {
				json[name] = [element.value];
			}
		}
		if(submit && submit.name) {
			json[submit.name] = submit.value;
		}
		return json;
	},
	
    /**
     * @return {Array} array of strings for successful data.
     */
	getMultipartFormData : function(e) {
	// Doesn't encode data.
	// http://groups.google.com/group/comp.lang.javascript/browse_thread/thread/eada69993b5ae08a/5943a32b5ecca6e6?lnk=gst&q=encodeURIComponent+post+xhr#5943a32b5ecca6e6
	// http://www.devx.com/Java/Article/17679/1954
		var json = this.toObject(e), prop, value, i, len, result = [],
			nn = '\r\n\r\n';
		for(prop in json) {
			value = json[prop];
			for(i = 0, len = value.length; i < len; i++) {
				value = value[i];
				if(!value) continue;
				result[result.length] = "Content-Disposition: form-data; " +
					'name="'+prop +'";'
					+ (value.fileName ? ' filename="'+value.fileName +'"'
						+ nn + value.getAsBinary() : nn + value);
				}
		}
		return result;
	},
	
	getQueryString : function(e) {
		var json = this.toObject(e), prop, value, result = [];
		for(prop in json) {
			value = json[prop];
			if(typeof value == "string") {
				result[result.length] = encodeURIComponent(prop)
				 + "=" + encodeURIComponent(value);
			} 
		}
		return result.join("&")
	},
	            
	serialize : function(e) {
		var method = this.form.method.toLowerCase();
		if(method == "get") {
			return this.action + "?" + getQueryString(e);	
		}
		if(method == "post") {
			if(this.form.enctype == "multipart/form-data")
				return this.getMultipartFormData(e);
			return this.getQueryString(e);
		}
	}
};